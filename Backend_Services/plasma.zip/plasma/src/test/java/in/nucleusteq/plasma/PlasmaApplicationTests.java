package in.nucleusteq.plasma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlasmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
